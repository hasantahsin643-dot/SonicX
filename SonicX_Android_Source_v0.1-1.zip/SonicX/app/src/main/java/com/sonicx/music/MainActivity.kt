package com.sonicx.music

import android.Manifest
import android.content.ComponentName
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture

data class LocalTrack(val id: Long, val title: String, val artist: String, val uri: Uri)

class MainActivity : AppCompatActivity() {
    private lateinit var listBox: LinearLayout
    private lateinit var status: TextView
    private lateinit var nowPlaying: TextView
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null
    private val tracks = mutableListOf<LocalTrack>()

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) loadTracks() else status.text = "গান দেখতে Audio permission প্রয়োজন।"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        connectPlayer()
        checkPermissionAndLoad()
    }

    private fun buildScreen() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(42, 42, 42, 24)
            setBackgroundColor(0xFF090812.toInt())
        }
        val logo = TextView(this).apply {
            text = "ϟ  SonicX"
            textSize = 28f
            setTextColor(0xFFC69AFF.toInt())
            gravity = Gravity.CENTER_VERTICAL
        }
        val tagline = TextView(this).apply {
            text = "YOUR SOUND. YOUR WORLD."
            textSize = 10f
            letterSpacing = 0.18f
            setTextColor(0xFF9B96AD.toInt())
        }
        val heading = TextView(this).apply {
            text = "Your music,\nyour vibe."
            textSize = 29f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 34, 0, 18)
        }
        status = TextView(this).apply {
            text = "ফোনের গান খোঁজা হচ্ছে..."
            textSize = 13f
            setTextColor(0xFFBEB5D0.toInt())
            setPadding(0, 0, 0, 14)
        }
        nowPlaying = TextView(this).apply {
            text = "কোনো গান চলছে না"
            textSize = 14f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 14, 0, 14)
        }
        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        controls.addView(controlButton("⏮") { controller?.seekToPreviousMediaItem() })
        controls.addView(controlButton("▶ / ❚❚") {
            controller?.let { if (it.isPlaying) it.pause() else it.play() }
        })
        controls.addView(controlButton("⏭") { controller?.seekToNextMediaItem() })
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        page.addView(logo)
        page.addView(tagline)
        page.addView(heading)
        page.addView(status)
        page.addView(nowPlaying)
        page.addView(controls)
        val listTitle = TextView(this).apply {
            text = "ON YOUR DEVICE"
            textSize = 11f
            letterSpacing = 0.16f
            setTextColor(0xFFC69AFF.toInt())
            setPadding(0, 28, 0, 12)
        }
        page.addView(listTitle)
        page.addView(listBox)
        val scroll = android.widget.ScrollView(this).apply { addView(page) }
        setContentView(scroll)
    }

    private fun controlButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            textSize = 12f
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF34224F.toInt()))
            setOnClickListener { action() }
        }

    private fun connectPlayer() {
        val token = SessionToken(this, ComponentName(this, MusicService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture?.addListener({
            try {
                controller = controllerFuture?.get()
                updateNowPlaying()
            } catch (_: Exception) {
                status.text = "Player connection হয়নি। অ্যাপ আবার খুলে দেখুন।"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun checkPermissionAndLoad() {
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
                         else Manifest.permission.READ_EXTERNAL_STORAGE
        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) {
            loadTracks()
        } else permissionLauncher.launch(permission)
    }

    private fun loadTracks() {
        tracks.clear()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST
        )
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        val sort = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        val cursor: Cursor? = contentResolver.query(collection, projection, selection, null, sort)
        cursor?.use {
            val idCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            while (it.moveToNext()) {
                val id = it.getLong(idCol)
                val uri = Uri.withAppendedPath(collection, id.toString())
                tracks.add(LocalTrack(id, it.getString(titleCol) ?: "Unknown title",
                    it.getString(artistCol) ?: "Unknown artist", uri))
            }
        }
        listBox.removeAllViews()
        status.text = if (tracks.isEmpty()) "এই ফোনে কোনো local music পাওয়া যায়নি।" else "${tracks.size} টি গান পাওয়া গেছে"
        tracks.forEachIndexed { index, track ->
            val row = TextView(this).apply {
                text = "♫  ${track.title}\n     ${track.artist}"
                textSize = 14f
                setTextColor(0xFFF7F4FF.toInt())
                setPadding(14, 16, 14, 16)
                setBackgroundColor(if (index % 2 == 0) 0xFF151322.toInt() else 0xFF0F0D19.toInt())
                setOnClickListener { playTrack(index) }
            }
            listBox.addView(row)
        }
    }

    private fun playTrack(index: Int) {
        val player = controller ?: run {
            Toast.makeText(this, "Player প্রস্তুত হচ্ছে, একটু পরে চেষ্টা করুন", Toast.LENGTH_SHORT).show()
            return
        }
        val items = tracks.map { MediaItem.fromUri(it.uri) }
        player.setMediaItems(items, index, 0L)
        player.prepare()
        player.play()
        nowPlaying.text = "এখন চলছে: ${tracks[index].title}"
    }

    private fun updateNowPlaying() {
        controller?.currentMediaItem?.mediaMetadata?.title?.let { nowPlaying.text = "এখন চলছে: $it" }
    }

    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controller = null
        super.onDestroy()
    }
}
