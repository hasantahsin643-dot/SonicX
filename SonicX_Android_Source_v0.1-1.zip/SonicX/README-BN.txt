SonicX Android Starter v0.1

এটি Android Studio-তে খোলার জন্য native Android source project। APK নয়।

এই starter-এ:
- ফোনের MediaStore থেকে local music list
- Audio permission
- Media3 ExoPlayer + MediaSessionService
- Play/Pause, Previous/Next
- ব্যাকগ্রাউন্ড playback service-এর ভিত্তি
- Premium dark/purple UI

Build করার নিয়ম:
1. ZIP extract করুন।
2. Android Studio-তে SonicX ফোল্ডারটি Open করুন।
3. Gradle sync শেষ হতে দিন (ইন্টারনেট লাগবে dependencies নামাতে)।
4. Android ফোন USB debugging দিয়ে connect করুন অথবা emulator চালান।
5. Run চাপুন। ফোনে Audio permission দিন।

গুরুত্বপূর্ণ:
- এখানে এখনো online search/catalogue, download manager, equalizer বা full lock-screen controls UI যোগ হয়নি।
- Android Studio/Gradle দিয়ে build ও real-device test না করে এটিকে verified APK বলা যাবে না।
- অনলাইন গান যুক্ত করতে licensed provider/API এবং তাদের অনুমোদিত playback rules মানতে হবে।
- App-এ নিজস্ব ad SDK নেই; তৃতীয়-পক্ষ provider-এর নিজস্ব বিজ্ঞাপন/শর্ত আলাদা হতে পারে।

ডিজাইন:
MainActivity.kt-এ মূল UI, MusicService.kt-এ playback service।
Theme colour app/src/main/res/values/styles.xml-এ।
